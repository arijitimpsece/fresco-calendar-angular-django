export class DateInMonth {
    date: string;
    enabled: boolean;
    constructor() {
        this.enabled = false;
        this.date = "0/00/0000";
    }
}
